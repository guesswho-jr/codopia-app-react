<?php

require_once "./scripts/classes.php";

$db = new DataBase();
