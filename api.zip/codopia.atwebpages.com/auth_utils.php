<?php

declare(strict_types=1);
require_once "./instance.php";
require_once "./scripts/validation.php";
require_once "./codes.php";
require_once "./scripts/classes.php";
require_once './scripts/PHPMailer/src/Exception.php';
require_once './scripts/PHPMailer/src/PHPMailer.php';
require_once './scripts/PHPMailer/src/SMTP.php';
require_once "./dotenv.php";
class JWT
{
    public function __construct(private string $key)
    {
    }
    private function url_encode(string $text): string
    {
        return str_replace(['+', '/', '='], ['-', '_', ''], base64_encode($text));
    }
    public function encode(array $payload): string
    {
        $header = json_encode([
            "alg" => "HS256",
            "typ" => "JWT"
        ]);
        $header = $this->url_encode($header);
        $payload = json_encode($payload);
        $payload = $this->url_encode($payload);

        $signiture = hash_hmac("sha256", $header . "." . $payload, $this->key, true);
        $signiture = $this->url_encode($signiture);
        return $header . "." . $payload . "." . $signiture;
    }
    public function decode(string $token): array | bool
    {
        if (preg_match("/^(?<header>.+)\.(?<payload>.+)\.(?<signiture>.+)$/", $token, $matches) !== 1) {
            return false;
        }
        $signiture = hash_hmac("sha256", $matches["header"] . "." . $matches["payload"], $this->key, true);
        $signiture_got = $this->url_decode($matches["signiture"]);
        if (!hash_equals($signiture_got, $signiture)) {
            return false;
        }
        $payload = (array)json_decode($this->url_decode($matches["payload"]), true);
        return $payload;
    }
    public function decode_for_app(string $token): string | bool
    {
        if (preg_match("/^(?<header>.+)\.(?<payload>.+)\.(?<signiture>.+)$/", $token, $matches) !== 1) {
            return false;
        }
        $signiture = hash_hmac("sha256", $matches["header"] . "." . $matches["payload"], $this->key, true);
        $signiture_got = $this->url_decode($matches["signiture"]);
        if (!hash_equals($signiture_got, $signiture)) {
            return false;
        }
        $payload = $this->url_decode($matches["payload"]);
        return $payload;
    }
    private function url_decode(string $val): string
    {
        return base64_decode(str_replace(["-", "_"], ["+", "/"], $val));
    }
}

function login(string $data)
{
    if ($_SERVER["REQUEST_METHOD"] !== "POST") {
        http_response_code(405);
        header("ALLOW: POST");
        exit;
    }

    function both_($val)
    {
        return isset($val) && !empty($val);
    }
    $data = (array)json_decode($data, true)["data"];
    if (!isset($data["username"]) || !isset($data['password'])) {
        http_response_code(403);
        return json_encode([
            "code" => 403,
            "payload" => $data
        ]);
    }
    if (!(both_($data["username"]) && both_($data["password"]))) {
        http_response_code(403);
        return json_encode([
            "code" => 403,
            "payload" => $data
        ]);
    }
    global $db;
    $user = $db->executeSql("select id, username, points, uploads, password from users where username=? limit 1", [$data["username"]], true);
    // print_r($user);
    if ($user["rows"] == 0) {
        return json_encode([
            'code' => EMPTY_RESPONSE
        ]);
    }
    if (!password_verify($data["password"], $user[0]["password"])) {
        http_response_code(403);
        return json_encode([
            "code" => PASSWORD_DONT_MATCH
        ]);
    }
    unset($user["rows"]);
    $payload = [
        "username" => $user[0]["username"],
        "points" => $user[0]["points"],
        "uploads" => $user[0]["uploads"],
        "user_id" => $user[0]["id"]
    ];
    $jwtCont = new JWT($_ENV["KEY"]);
    return json_encode([
        "token" => $jwtCont->encode($payload)
    ]);
}

function sendEmail(string $to, $code)
{
        

$url = "https://donscience.000webhostapp.com/mail.php";
$data = array(
    'to' => $to,
    'code' => $code
);


$ch = curl_init($url);


curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));


$response = curl_exec($ch);
$error = curl_error($ch);
echo "Error is " . $error;
        exit;

if (strtolower($response) == "sent") {
    
    echo json_encode(["success"=>true]);
} else {
    echo json_encode(["success"=>false]);
}

curl_close($ch);



        
        
        }

    
   

    
       
          
       
       
       
       
       
       
        
        
       

       
       
       
       
       

    

class Authentication
{
    public function __construct(private JWT $jwt)
    {
    }

    public function authenticate(): bool
    {
        $headers = apache_request_headers();

        if (isset($_SERVER['HTTP_AUTHORIZATION']) || isset($headers["authorization"]) || isset($headers["Authorization"])) {
            if (isset($_SERVER['HTTP_AUTHORIZATION'])) {
                $data = $_SERVER['HTTP_AUTHORIZATION'];
            } else if (isset($headers["authorization"])) {
                $data = $headers["authorization"];
            } else if (isset($headers["Authorization"])) {
                $data = $headers["Authorization"];
            } else {
                return false;
            }
            if (!preg_match("/^Bearer\s+(.*)$/", $data, $matches)) {
                http_response_code(400);
                return false;
            }
            if (!$this->jwt->decode($matches[1])) {
                return false;
            }
            return true;
        } else {
            return false;
        }
    }
}

class SignUpForApp extends DataBase
{
    private $file;
    public function __construct(
        private string $username,
        private string $password,
        private string $cpassword,
        private string $bio,
        private string $full_name,
        private string $email,
    ) {
        parent::__construct();
        if ($this->cpassword !== $this->password) {
            throw new Exception("Passwords don't match");
        }
        $this->file = "cache" . DIRECTORY_SEPARATOR . "$this->username-file.cache";
    }

    private function setCodeForUser(int $code, int $trials = 1, int $code_sent = 1)
    {
        if (file_exists($this->file)) {
            unlink($this->file);
        }
        $data = [
            "username" => $this->username,
            "code" => $code,
            "issue_time" => time(),
            "trials" => $trials,
            "code_sent" => $code_sent
        ];
        file_put_contents($this->file, base64_encode(json_encode($data)));
    }
    private function getCodeForUser()
    {
        if (!file_exists($this->file)) {
            return false;
        }
        $data = file_get_contents($this->file);
        if (!$data) {
            http_response_code(500);
            throw new Exception("Error occured on our side. Please report it");
        }
        return (array)json_decode(base64_decode($data), true);
    }

    public function sendCode()
    {
        $code = random_int(100000, 999999);
        if (!file_exists($this->file)) {
            $this->setCodeForUser($code);
        }
         sendEmail($this->email, $code);

        $returned = $this->getCodeForUser();
        if ($returned["code_sent"]) {
            if ((int)$returned["trials"] >= 5) {
                throw new Exception("No more trials");
            }
            $this->setCodeForUser($code, (int)$returned["trials"] + 1, 1);
        }
    }
    public function checkCode($code)
    {
        if (!file_exists($this->file)) {
            die(json_encode(["error" => "Code is not sent yet!"]));
        }
        $file = $this->getCodeForUser();
        $realCode = (int)$file["code"];
        if ($realCode === $code) {
            $time = (int)$file["issue_time"];
            if (time() - $time < 300) {
                $this->cleanUp();
                return true;
            }
            return false;
        }
        return false;
    }
    public function cleanUp()
    {
        unlink($this->file);
    }
    public function createUser()
    {
        $userCont = new User($this->username, $this->password);
        return $userCont->createUser($this->username, $this->password, $this->cpassword, $this->bio, $this->full_name, $this->email);
    }
    // public function __destruct()
    // {
    //     $this->cleanUp();
    // }
}
