<?php

class UserNotFoundException extends Exception
{
}

class CacheException extends Exception
{
}

class MailException extends Exception
{
}

class MaximumTrials extends Exception
{
}
